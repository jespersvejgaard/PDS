
###################################################################################################################
###################################################################################################################
# DEFINE PACKAGES
pack <- c("sp", "rgdal", "raster", "countrycode", "dplyr", "geosphere", "tmap", "tmaptools")

# INSTALL PACKAGES
#lapply(pack, install.packages) # Run this if packages are not already installed.

# LOAD PACKAGES 
lapply(pack, require, character.only=T); rm(pack)
rm(list=ls())

# SET WORKING DIRECTORY
setwd(".../08_opgaver")  # change this to the location of the folder "08_opgaver" on your own computer 

######INFORMATION ON DATA:
## >> tobacco_africa.tif: file containing info on the harvested area fraction of small gridcells (squares) across Africa
## >> region.shp: file containing info in the location of ADM1 (i.e. regional level) areas across Africa
## >> SA_survey.shp: subset of survey respondents in South Africa
## >> Voting_District.shp: file on voting districts locations in South Africa (subset)
## >> voting_stations.shp: file on voting station locations in South Africa (subset)
## >> ZAP_adm0.shp: file containing data describing South Africa, including a polygon of the country 

###################################################################################################################
###################################################################################################################
## EXERCISE 1: READ SPATIAL DATA                                                                                      | 1 |
## >> Read in data: 
## >> Get a sense of the data using plot(). If you want to plot two shp's together, simply plot them separately, 
## >> adding 'add=T' to the plot function called last: plot(shp1); plot(shp2, col="red", add=T)
## >> use ReadOGR() and raster(). Check projections using Proj4string()
###################################################################################################################
###################################################################################################################

# Read in data
tobacco <- raster("tobacco_africa.tif")
region <- readOGR("GADM_africa.shp")
survey <- readOGR("SA_survey.shp")
voting_districts <- readOGR("Voting_districts.shp")
voting_stations <- readOGR("voting_stations.shp")
South_africa <- readOGR("ZAF_adm0.shp")

# Check if projections are the same 
proj4string(region)==proj4string(survey)
proj4string(survey)==proj4string(voting_districts)
proj4string(voting_districts)==proj4string(voting_stations)


# Get a sense of the data playing around with plot()
___


# Shortly describe the data you have just loaded in 
...


###################################################################################################################
###################################################################################################################
## EXERCISE 2:  MAPOVERLAYING (shapefile & shapefile)                                                                 | 2 |
## >> For each respondent in the survey, assign the 'VDNumber' of the voting district, within which the respondent
## >> resides as a variable. 
## >> use over()
## >> !! Interpret the output: how does the output help you? (see 'Value' in ?over)
###################################################################################################################
###################################################################################################################

# Matching attributes of the 'voting_districts' to the respondents in 'survey'
overlay <- over(survey, voting_districts)  

# Adding VDNumber to the survey respondents 
survey$VDNumber <- overlay$VDNumber  


# Why is the procedure above smart? Describe some perspectives of this approach beyond this particular case 
...


###################################################################################################################
###################################################################################################################
## EXERCISE 3:  CALCULATING DISTANCES                                                                                 | 3 |                                                                                                   | 3 |
## >> For each respondent in the survey, calculate the distance to the closest 1) voting station, 2) voting 
## >> district border. What is the average distance to the closest voting station? To the voting district border,
## >> use dist2Line
## >> !! Consider: does the code account for the fact that the closest voting stations might not necessarily be 
## >>    the assigned voting station? If not, what could you do, in order to calculate the correct distance?
###################################################################################################################
###################################################################################################################

# Calculating distances from respontens in 'survey' to voting stations and voting district borders 
survey$voting_st_dist <- dist2Line(survey, voting_stations)[,1]
survey$district_dist <- dist2Line(survey, voting_districts)[,1]

# What is the average distance to the closest voting station?
___


###################################################################################################################
###################################################################################################################
## EXERCISE 4: MAPOVERLAYING (for one raster object & one shapefile object)                                           | 4 |
## >> What region (of what country) harvests most tobacco (measured as harvested area fraction)? 
## >> Use extract()
## !! See 'df' and 'fun' in ?extract. 
###################################################################################################################
###################################################################################################################

# Extracting values from the raster object 'tobacco' for the regions in the shp file 'region'
overlay <- extract(tobacco, region, fun = mean, df=TRUE)  # takes around 10 minutes to run 

# Binding columns together
result <- cbind(region@data[, c("NAME_0", "NAME_1")], overlay)


# What region in which country harvests the most tobacco? Use your dplyr skills on the 'result' dataframe
___


# Describe with your own words: What happens in the code above? 
...


###################################################################################################################
###################################################################################################################
## EXERCISE 5: CALCULATE AREAS                                                                                        | 5 |
## >> What region covers the largest area in Africa? What country covers the largest area?
## >> Use area()     (and group_by?)
###################################################################################################################
###################################################################################################################

# Calculating areas
region$area_size <- area(region)
region$area_size <- region$area_size/1000000

# Order 'region@data' according to area size with the largest ones first 
region@data <- region@data %>% ___(desc(area_size))

# Which five regions are the biggest? (the variable 'NAME_1' contains region names)
___

# Which five countries are the biggest? (the variable 'NAME_0' contains region names)
region@data %>% group_by(___) %>% summarize(total_area = sum(round(___, digits=0), na.rm=T)) %>% arrange(desc(___))


# Describe with your own words: What happens in the code above? 
...


# Does your resulting top 5 largest countries correspond to what Wikipedia has to say? If no, why might this be? Hint: see ?area
... 


###################################################################################################################
###################################################################################################################
## EXERCISE 6: PLOTTING SHAPEFILES                                                                                    | 6 |
## >> Plot respondents, voting districts and voting stations across south africa
## >> tm_shape
###################################################################################################################
###################################################################################################################

# Plot
map <- tm_shape(South_africa) + tm_polygons("green", alpha=0.1) + 
          tm_shape(voting_districts) + tm_polygons(alpha=0.4) +
              tm_shape(survey) + tm_dots(size=0.05, "red") +
                  tm_shape(voting_stations) + tm_dots(size=0.05, "blue", alpha=0.6)

# Take a look at the map
map


# Use you own words to describe the logic in the plot script above
... 



















